// ���� Delay-Load ���� unload �\��

#include "stdafx.h"
#include <windows.h>
#include <delayimp.h>              // for __FUnloadDelayLoadedDLL2

#include "MyLib.h"             
#include <iostream>
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	// MyDLL.DLL will load at this point
		int d=Add(1,2);  
		cout << d << endl;

	// MyDLL.DLL will unload at this point
		BOOL TestReturn = __FUnloadDelayLoadedDLL2("MyDLL.dll");
		if (TestReturn)
			printf("\nDLL was unloaded");
		else
			printf("\nDLL was not unloaded");
		return 0;
}

