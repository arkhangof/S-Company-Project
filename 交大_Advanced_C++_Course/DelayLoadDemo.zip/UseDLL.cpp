// UseDLL.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MyLib.h"             // << ---------- �ޤJ���n�����Y��
#include <iostream>
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int d=Add(1,2);
    cout << d << endl;
	
	return 0;
}

