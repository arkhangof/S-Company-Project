// ���� Delay-Load ���� unload �\��

#include "stdafx.h"
#include <windows.h>
#include <delayimp.h>              // for __FUnloadDelayLoadedDLL2

#include "MyLib.h"             
#include <iostream>
using namespace std;

// �d�I __DelayLoadHelp �� function
FARPROC WINAPI DliHook(unsigned dliNotify, PDelayLoadInfo pdli); 
// Tell __delayLoadHelper to call my hook function
PfnDliHook __pfnDliNotifyHook2  = DliHook;
PfnDliHook __pfnDliFailureHook2 = DliHook;

int _tmain(int argc, _TCHAR* argv[])
{
	
	// MyDLL.DLL will load at this point
		int d=Add(1,2);  
		cout << d << endl;

	

	// MyDLL.DLL will unload at this point
		BOOL TestReturn = __FUnloadDelayLoadedDLL2("MyDLL.dll");
		if (TestReturn)
			printf("\nDLL was unloaded");
		else
			printf("\nDLL was not unloaded");
		return 0;
}

// �`�N => pdli ���@�ӫ��V PDelayLoadInfo ���c������
//         ����ܥثe __delayLoadHelper �B�z���i��
FARPROC WINAPI DliHook(unsigned dliNotify, PDelayLoadInfo pdli) {

   FARPROC fp = NULL;   // �w�]�Ǧ^��
   
   switch (dliNotify) {
   case dliStartProcessing:
	  // �� __delayLoadHelper ���ϴM��@�� DLL function ��, �|�Q�I�s
	  // �Ǧ^��: NULL => ������ ; 
	  //         nonzero => override everything
      MessageBox(NULL,"���ϴM��@�� DLL","Info",MB_OK);
      break;

   case dliNotePreLoadLibrary:
      // Called just before LoadLibrary
      // Return NULL to have __delayLoadHelper call LoadLibary
      // or you can call LoadLibrary yourself and return the HMODULE
      fp = (FARPROC) (HMODULE) NULL;
	  MessageBox(NULL,"before LoadLibrary","Info",MB_OK);
      break;

   case dliFailLoadLib:
      // Called if LoadLibrary fails
      // Again, you can call LoadLibary yourself here and return an HMODULE
      // If you return NULL, __delayLoadHelper raises the 
      // ERROR_MOD_NOT_FOUND exception
      fp = (FARPROC) (HMODULE) NULL;
	  MessageBox(NULL," LoadLibrary fails","Info",MB_OK);
      break;

   case dliNotePreGetProcAddress:
      // Called just before GetProcAddress
      // Return NULL to have __delayLoadHelper call GetProcAddress
      // or you can call GetProcAddress yourself and return the address
      fp = (FARPROC) NULL;
	  MessageBox(NULL,"before GetProcAddress","Info",MB_OK);
      break;

   case dliFailGetProc:
      // Called if GetProcAddress fails
      // You can call GetProcAddress yourself here and return an address
      // If you return NULL, __delayLoadHelper raises the 
      // ERROR_PROC_NOT_FOUND exception
      fp = (FARPROC) NULL;
	  MessageBox(NULL,"GetProcAddress fails","Info",MB_OK);
      break;

   case dliNoteEndProcessing:
      // A simple notification that __delayLoadHelper is done
      // You can examine the members of the DelayLoadInfo structure
      // pointed to by pdli and raise an exception if you desire
	   MessageBox(NULL,"done","Info",MB_OK);
      break;
   }

   return(fp);
}



