// DLL export function ��@��
// MyLib.h �� prototype

#include <windows.h>
#define MYLIBExport            // ���ܳo�� .cpp �ɭn export symbol
#include "MyLib.h"
#include <iostream>
using namespace std;

int g_nResult;

MYLIBAPI int Add(int nLeft, int nRight) {
   g_nResult = nLeft + nRight;
   return(g_nResult);
}

BOOL WINAPI DllMain(HINSTANCE hinstDll, DWORD fdwReason, PVOID fImpLoad) {
   switch (fdwReason) {
      case DLL_PROCESS_ATTACH:
         cout <<"MyDLL is being mapped into the process's address space.\n";
		 return(TRUE); 
         break;
      case DLL_THREAD_ATTACH:
         cout << "A thread is being created.\n";
		 return(FALSE); 
         break;

      case DLL_THREAD_DETACH:
         cout << "A thread is exiting cleanly.\n";
		 return(FALSE); 
         break;

      case DLL_PROCESS_DETACH:
         cout << "MyDLL is being unmapped from the process's address space.\n";
		 return(FALSE); 
         break;
   }
   return(FALSE);  // Used only for DLL_PROCESS_ATTACH
}

