// UseDLL.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
typedef int (*ADDPF)(int,int);
int _tmain(int argc, _TCHAR* argv[])
{
	HMODULE hModule=LoadLibrary("MyDLL.dll");
	ADDPF pf=(ADDPF)GetProcAddress(hModule,(LPCSTR)12345);
	int c=(*pf)(1,2);
	return 0;
}

