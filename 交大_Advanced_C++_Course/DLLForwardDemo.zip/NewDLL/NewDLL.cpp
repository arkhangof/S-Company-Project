// �o�� NewDLL �O�ΨӴ��� DLL forword �\��ϥ�
// ���A�I�s MyDLL �� Add function, �|�۰� forward �� NewDLL �� NewAdd function ���� 
#include "stdafx.h"
// #define NEWDLL_EXPORTS
#include "NewDLL.h"
#include <iostream>
using namespace std;

// =============================================================================
NEWDLL_API int NewAdd(int a,int b){
	return a+b+10;
}
// =============================================================================


BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		cout << " NewDLL is loaded" << endl;
		break;
	case DLL_THREAD_ATTACH:
		cout << " NewDLL's thread is start" << endl;
		break;
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}


