// �Y�A�Q�ϥΤU�� export �� symbol, �A�����n include �o���ɮ�

#ifdef NEWDLL_EXPORTS
#define NEWDLL_API extern "C" __declspec(dllexport)
#else
#define NEWDLL_API extern "C" __declspec(dllimport)
#endif

// =============================================================================
NEWDLL_API int NewAdd(int a,int b);          // New Add prototype
// =============================================================================

NEWDLL_API int fnNewDLL(void);
